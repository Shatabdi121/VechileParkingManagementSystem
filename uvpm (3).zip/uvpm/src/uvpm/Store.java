package uvpm;

public class Store {
static String name;
static String vechileNo;

}
